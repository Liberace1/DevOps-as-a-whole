## Files Size

### Objectives

1. Print the name and size of every file and directory in current path

Note: use at least one for loop!
