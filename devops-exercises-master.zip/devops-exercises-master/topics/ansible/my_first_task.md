## Ansible - My First Task

1. Write a task to create the directory ‘/tmp/new_directory’
