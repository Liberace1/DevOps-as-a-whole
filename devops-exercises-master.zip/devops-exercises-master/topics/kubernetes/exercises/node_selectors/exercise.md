# Node Selectors

## Objectives

1. Apply the label "hw=max" on one of the nodes in your cluster
2. Create and run a Pod called `some-pod` with the image `redis` and configure it to use the selector `hw=max`
3. Explain why node selectors might be limited


## Solution

Click [here](solution.md) to view the solution