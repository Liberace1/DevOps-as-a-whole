# Taints 101

## Objectives

1. Check if one of the nodes in the cluster has taints (doesn't matter which node)
2. Create a taint on one of the nodes in your cluster with key of "app" and value of "web" and effect of "NoSchedule"
   1. Explain what it does exactly
   2. Verify it was applied
3. Run a Pod that will be able to run on the node on which you applied the taint

## Solution

Click [here](solution.md) to view the solution.