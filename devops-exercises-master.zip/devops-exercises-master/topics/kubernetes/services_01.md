## Services 01

#### Objective

Learn how to create services

#### Instructions

1. Create a pod running ngnix
2. Create a service for the pod you've just created
3. Verify the app is reachable
