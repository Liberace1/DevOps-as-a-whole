### Jenkins - Remove Jobs

#### Objective 

Learn how to write a Jenkins script to remove Jenkins jobs

#### Instructions

1. Create three jobs called: test-job, test2-job and prod-job
2. Write a script to remove all the jobs that include the string "test"
