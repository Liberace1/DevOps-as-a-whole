# Assign Roles

## Objectives

1. Assign the following roles to a member in your organization
   1. Compute Storage Admin
   2. Compute Network Admin
   3. Compute Security Admin
2. Verify roles were assigned

## Solution

Click [here](solution.md) to view the solution
