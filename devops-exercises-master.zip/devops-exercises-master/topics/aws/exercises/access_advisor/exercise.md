## AWS IAM - Access Advisor

### Objectives

Go to the Access Advisor and answer the following questions regarding one of the users:

1. Are there services this user never accessed?
2. What was the last service the user has accessed?
3. What the Access Advisor is used/good for?

## Solution

Click [here to view to solution](solution.md)