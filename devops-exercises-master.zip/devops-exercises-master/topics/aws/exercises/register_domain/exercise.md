## AWS Route 53 - Register Domain

### Objectives

Note: registering domain costs money. Don't do this exercise, unless you understand that you are going to register a domain and it's going to cost you money.

1. Register your own custom domain using AWS Route 53
2. What is the type of your domain?
3. How many records your domain has?
