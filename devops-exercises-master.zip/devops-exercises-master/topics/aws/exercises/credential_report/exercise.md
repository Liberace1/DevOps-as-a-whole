## AWS - Credential Report

### Objectives

1. Create/Download a credential report
2. Answer the following questions based on the report:
  1. Are there users with MFA not activated?
  2. Are there users with password enabled that didn't 
3. Explain the use case for using the credential report
