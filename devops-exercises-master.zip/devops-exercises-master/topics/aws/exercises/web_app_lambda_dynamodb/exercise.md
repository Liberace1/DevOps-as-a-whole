# Web App with DB

## Objectives

Implement the following architecture:

<TODO>

## Solution

Click [here](solution.md) to view the solution