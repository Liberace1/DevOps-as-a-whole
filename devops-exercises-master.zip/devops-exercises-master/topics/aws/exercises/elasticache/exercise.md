## AWS ElastiCache

### Objectives

1. Create ElastiCache Redis
  * Instance type should be "cache.t2.micro"
  * Replicas should be 0
