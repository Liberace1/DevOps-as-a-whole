## Comparisons vs. Functions

1. Improve the following query

```
SELECT COUNT(purchased_at)
FROM shawarma_purchases
WHERE purchased_at BETWEEN '2017-01-01' AND '2017-12-31';
```
