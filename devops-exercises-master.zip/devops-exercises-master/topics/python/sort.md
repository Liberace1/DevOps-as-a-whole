## Sort Descending 

1. write a function that sorts the following list of list without using the `sorted()` and `.sort()`
   function in descending order

   - list = [[1, 2, 3], [2, 4, 4], [5, 5, 5]] -> [[5, 5, 5], [2, 4, 4], [1, 2, 3]]
